static void Check(bool b, string s) { if (!b) throw new Exception(s); }
var d = new WorkerDiagnostics();
Check(!d.Compatible, "no unconfirmed backend accepted");
d.Read("BACKEND_VERSION: 0.3.0"); Check(!d.Compatible && d.Describe(4).Contains("版本"), "old backend detected");
d.Read("BACKEND_VERSION: 0.3.1"); Check(d.Compatible, "matching backend");
d.Read("FAILURE_CODE: IO"); d.Read("Unhandled System.IO.IOException: PRIVATE_ACCOUNT C:\\SECRET_PATH");
Check(d.Describe(-1).Contains("IOException") && d.Describe(-1).Contains("退出碼 -1"), "exit and type available");
Check(!d.Describe(-1).Contains("PRIVATE") && !d.Describe(-1).Contains("SECRET"), "no raw exception leakage");
d.Read("ATTEMPT: AUTO_INVOKE_ONCE"); Check(d.Describe(3).Contains("可能已送出"), "attempt warning scoped to actual attempt");
var fresh = new WorkerDiagnostics(); fresh.Read("BACKEND_VERSION: 0.3.1"); fresh.Read("FAILURE_CODE: TARGET_OR_PERMISSION");
Check(fresh.Describe(4).Contains("權限") && fresh.Describe(4).Contains("未記錄"), "startup vs attempted failure");
Console.WriteLine("PASS: 7 diagnostic checks (version matching, early exit, safe metadata, attempted status).");
