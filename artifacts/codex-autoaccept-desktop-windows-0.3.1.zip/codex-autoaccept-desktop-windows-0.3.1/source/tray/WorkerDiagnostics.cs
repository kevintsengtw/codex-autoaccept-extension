using System;
using System.Text.RegularExpressions;

// Metadata only. Never retain raw stderr, exception messages, UI text or paths.
internal sealed class WorkerDiagnostics
{
    public const string ExpectedVersion = "0.3.1";
    readonly object sync = new object();
    string version, errorType, failure;
    bool attempted;
    public bool Compatible { get { lock (sync) return version == ExpectedVersion; } }
    public void Read(string line)
    {
        lock (sync)
        {
            if (line.StartsWith("BACKEND_VERSION: "))
            {
                var v = line.Substring("BACKEND_VERSION: ".Length);
                if (Regex.IsMatch(v, @"^\d{1,3}\.\d{1,3}\.\d{1,5}$")) version = v;
            }
            if (line == "ATTEMPT: AUTO_INVOKE_ONCE") attempted = true;
            if (line.StartsWith("FAILURE_CODE: "))
            {
                var f = line.Substring("FAILURE_CODE: ".Length);
                if (f == "ARGUMENTS_OR_WINDOW" || f == "TARGET_OR_PERMISSION" || f == "IO" || f == "OTHER") failure = f;
            }
            foreach (var type in new[] { "IOException", "UnauthorizedAccessException", "SecurityException", "ArgumentException", "FileNotFoundException", "BadImageFormatException", "TypeInitializationException", "ManualRefusalException" })
                if (Regex.IsMatch(line, @"\b" + type + @"\b")) { errorType = type; break; }
        }
    }
    public string Describe(int exitCode)
    {
        lock (sync)
        {
            string reason = version != ExpectedVersion ? "後端版本未確認或不符，請完整解壓同一版 ZIP。"
                : failure == "TARGET_OR_PERMISSION" ? "目標視窗已變更，或前後端與 App 權限不符。"
                : failure == "IO" ? "後端輸入輸出或本機紀錄初始化失敗。"
                : failure == "ARGUMENTS_OR_WINDOW" ? "後端啟動參數或目標視窗無效。" : "後端執行未完成。";
            return "後端退出碼 " + exitCode + "；錯誤類型 " + (errorType ?? "未取得") + "。\n" + reason
                + (attempted ? " 核准可能已送出，請先查看 App，再重新連接。" : " 本次未記錄核准嘗試，可重新選擇視窗或重新連接。");
        }
    }
}
