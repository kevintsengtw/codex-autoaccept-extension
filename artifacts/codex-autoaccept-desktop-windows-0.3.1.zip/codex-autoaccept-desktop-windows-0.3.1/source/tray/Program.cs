using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;

internal static class TrayProgram
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        bool owner;
        using (var mutex = new Mutex(true, "Local\\CodexAutoAcceptDesktop-" + WindowsIdentity.GetCurrent().User.Value, out owner))
        {
            if (!owner) { MessageBox.Show("程式已在執行，請查看右下角系統匣（可能在隱藏圖示裡）。", "Codex Auto-Accept"); return; }
            try { Application.Run(new TrayContext()); }
            catch (Exception e) { MessageBox.Show("啟動失敗：" + e.GetType().Name + "。請確認完整解壓及公司允許程式執行。", "Codex Auto-Accept"); }
        }
    }
}
internal sealed class TargetWindow
{
    public long Hwnd, Started; public int Pid; public string Path, Name, Title;
    public override string ToString() { return Name + " · PID " + Pid + " · " + Title; }
}
internal sealed class Settings { public string TargetPath; }
internal sealed class TrayContext : ApplicationContext
{
    const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run", RunName = "CodexAutoAcceptDesktop";
    readonly DesktopState state = new DesktopState();
    readonly Form panel = new Form();
    readonly NotifyIcon tray = new NotifyIcon();
    readonly Label status = new Label(), target = new Label(), detail = new Label();
    readonly Button toggle = new Button(), choose = new Button(), reconnect = new Button();
    readonly CheckBox startup = new CheckBox();
    readonly ToolStripMenuItem toggleMenu = new ToolStripMenuItem();
    readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
    readonly string settingsFile = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CodexAutoAcceptDesktop", "settings.json");
    Settings settings = new Settings();
    Process worker;
    TargetWindow selected;
    Icon icon;
    bool busy, exiting, refreshStartup;
    int sent;
    public TrayContext()
    {
        if (File.Exists(settingsFile))
            try { settings = new JavaScriptSerializer().Deserialize<Settings>(File.ReadAllText(settingsFile)) ?? new Settings(); } catch { }
        panel.Text = "Codex Auto-Accept 0.3.1"; panel.ClientSize = new Size(540, 340);
        panel.FormBorderStyle = FormBorderStyle.FixedDialog; panel.MaximizeBox = false; panel.StartPosition = FormStartPosition.CenterScreen;
        panel.Font = new Font("Microsoft JhengHei UI", 10);
        status.SetBounds(20, 20, 500, 35); status.Font = new Font(panel.Font.FontFamily, 16, FontStyle.Bold);
        target.SetBounds(20, 65, 500, 50); target.AutoEllipsis = true;
        detail.SetBounds(20, 120, 500, 80);
        toggle.Text = "開啟 ON"; toggle.SetBounds(195, 205, 145, 40); toggle.Click += (s, e) => Toggle();
        choose.Text = "1. 選擇 App 視窗"; choose.SetBounds(20, 205, 165, 40); choose.Click += async (s, e) => await Choose();
        reconnect.Text = "重新連接"; reconnect.SetBounds(350, 205, 165, 40); reconnect.Click += async (s, e) => await Reconnect();
        startup.Text = "登入 Windows 時啟動（啟動後仍為 OFF）"; startup.SetBounds(20, 250, 495, 30); startup.CheckedChanged += (s, e) => ChangeStartup();
        var tip = new Label { Text = "先選擇 App，再開啟 ON。關閉視窗仍常駐；右鍵系統匣可退出。", AutoSize = false };
        tip.SetBounds(20, 295, 505, 30);
        panel.Controls.AddRange(new Control[] { status, target, detail, choose, toggle, reconnect, startup, tip });
        choose.TabIndex = 0; toggle.TabIndex = 1; reconnect.TabIndex = 2; startup.TabIndex = 3;
        panel.FormClosing += (s, e) => { if (e.CloseReason == CloseReason.WindowsShutDown) return; if (!exiting) { e.Cancel = true; panel.Hide(); tray.ShowBalloonTip(2000, "Codex Auto-Accept", "程式仍在系統匣執行，雙擊圖示可開啟設定。", ToolTipIcon.Info); } };
        var menu = new ContextMenuStrip();
        menu.Items.Add(toggleMenu); toggleMenu.Click += (s, e) => Toggle();
        menu.Items.Add("開啟設定", null, (s, e) => Show());
        menu.Items.Add("重新連接（回到 OFF）", null, async (s, e) => await Reconnect());
        menu.Items.Add(new ToolStripSeparator()); menu.Items.Add("退出", null, async (s, e) => await Exit());
        tray.ContextMenuStrip = menu; tray.Visible = true; tray.DoubleClick += (s, e) => Show();
        var uiHandle = panel.Handle; // Create marshal target even when launch stays entirely in the tray.
        ReadStartup(); Render();
        timer.Interval = 2000; timer.Tick += async (s, e) => { if (!busy && !exiting) await Attach(); }; timer.Start();
        if (string.IsNullOrWhiteSpace(settings.TargetPath)) Show();
    }
    void Show() { panel.Show(); panel.WindowState = FormWindowState.Normal; panel.Activate(); }
    void Ui(Action action) { if (!exiting && panel.IsHandleCreated) try { panel.BeginInvoke(action); } catch (InvalidOperationException) { } }
    void Toggle()
    {
        if (!state.Ready || busy) { Show(); return; }
        if (state.Faulted) { Show(); MessageBox.Show(panel, "後端已停止。請先查看 App 的核准狀態，再按「重新連接」。", "Codex Auto-Accept"); return; }
        state.Request(!state.DesiredOn);
        if (state.Ready) Send(state.DesiredOn ? "ON" : "OFF");
        Render();
    }
    void Render()
    {
        status.Text = state.Caption; toggle.Text = state.DesiredOn ? "2. 關閉 OFF" : "2. 開啟 ON"; toggleMenu.Text = state.DesiredOn ? "關閉 OFF" : "開啟 ON";
        toggle.Enabled = toggleMenu.Enabled = state.Ready && !state.Faulted && !busy;
        choose.Enabled = !busy; reconnect.Enabled = !busy && (selected != null || !string.IsNullOrEmpty(settings.TargetPath));
        target.Text = selected == null ? "尚未連接 App。第一次請選擇視窗；之後會記住 App 路徑。" : "目標：" + selected.Name + " · PID " + selected.Pid + "\n" + selected.Title;
        if (string.IsNullOrEmpty(detail.Text)) detail.Text = "每次啟動皆為 OFF。已送出的核准不會因切 OFF 而撤回。";
        tray.Text = "Codex Auto-Accept · " + state.Caption;
        using (var bitmap = new Bitmap(32, 32))
        using (var graphics = Graphics.FromImage(bitmap))
        using (var brush = new SolidBrush(state.Faulted ? Color.DarkOrange : state.Ready && state.ActualOn ? Color.ForestGreen : Color.DimGray))
        {
            graphics.Clear(Color.Transparent); graphics.FillEllipse(brush, 1, 1, 30, 30);
            using (var font = new Font("Arial", 16, FontStyle.Bold)) graphics.DrawString("A", font, Brushes.White, 5, 3);
            IntPtr handle = bitmap.GetHicon(); Icon next;
            try { next = (Icon)Icon.FromHandle(handle).Clone(); } finally { DestroyIcon(handle); }
            tray.Icon = next; if (icon != null) icon.Dispose(); icon = next;
        }
    }
    async Task Choose()
    {
        if (busy) return; busy = true; Render();
        try
        {
            var windows = await Task.Run(() => Windows());
            using (var picker = new Form { Text = "選擇 ChatGPT／Codex App", ClientSize = new Size(650, 280), StartPosition = FormStartPosition.CenterParent, MinimizeBox = false, MaximizeBox = false })
            {
                var list = new ListBox { Dock = DockStyle.Top, Height = 220, HorizontalScrollbar = true };
                list.Items.AddRange(windows.Cast<object>().ToArray());
                var ok = new Button { Text = "連接所選視窗", Dock = DockStyle.Bottom, Height = 40, DialogResult = DialogResult.OK };
                picker.Controls.Add(list); picker.Controls.Add(ok); picker.AcceptButton = ok;
                if (windows.Count == 0) { MessageBox.Show(panel, "未找到 App 視窗。請先開啟 ChatGPT／Codex App，再試一次。", "Codex Auto-Accept"); return; }
                if (picker.ShowDialog(panel) != DialogResult.OK || list.SelectedItem == null || exiting) return;
                var chosen = (TargetWindow)list.SelectedItem;
                state.Reset(); await Disconnect();
                settings.TargetPath = chosen.Path; SaveSettings(); StartWorker(chosen);
            }
        }
        catch (Exception e) { MessageBox.Show(panel, "選擇／連接失敗：" + e.GetType().Name, "Codex Auto-Accept"); }
        finally { busy = false; choose.Enabled = true; Render(); }
    }
    async Task Reconnect()
    {
        if (busy || exiting) return;
        var previous = selected;
        busy = true; state.Reset(); Render();
        try { await Disconnect(); if (previous != null && SameWindow(previous)) StartWorker(previous); }
        finally { busy = false; }
        if (worker == null) await Attach(); Render();
    }
    async Task Attach()
    {
        if (busy || exiting || state.Faulted) return;
        busy = true;
        try
        {
            if (selected != null && SameWindow(selected)) return;
            if (worker != null) await Disconnect();
            if (string.IsNullOrEmpty(settings.TargetPath)) { detail.Text = "請選擇 App 視窗。若路徑讀取受限，下次需重新選擇。"; Render(); return; }
            var windows = await Task.Run(() => Windows().Where(w => string.Equals(w.Path, settings.TargetPath, StringComparison.OrdinalIgnoreCase)).ToList());
            if (exiting) return;
            if (windows.Count == 1) StartWorker(windows[0]);
            else { detail.Text = windows.Count > 1 ? "找到多個符合視窗，請用「選擇 App 視窗」指定。" : "等待已選過的 App 開啟。"; Render(); }
        }
        catch (Exception e) { detail.Text = "連接失敗：" + e.GetType().Name; state.Disconnected(true); Render(); }
        finally { busy = false; }
    }
    void StartWorker(TargetWindow window)
    {
        var file = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CodexUiaManualInvoke.exe");
        if (!File.Exists(file)) throw new FileNotFoundException();
        selected = window;
        var p = new Process { StartInfo = new ProcessStartInfo(file, "--headless --hwnd " + window.Hwnd + " --max-depth 60")
            { UseShellExecute = false, CreateNoWindow = true, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true,
              StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8 }, EnableRaisingEvents = true };
        worker = p; state.BeginConnection(); detail.Text = "正在連接…";
        var diagnostics = new WorkerDiagnostics();
        p.OutputDataReceived += (s, e) => {
            if (e.Data == null) return;
            diagnostics.Read(e.Data); // Retain safe diagnostics even if exit races ahead of UI delivery.
            Ui(() => { if (ReferenceEquals(worker, p) && !p.HasExited) Receive(e.Data, diagnostics); });
        };
        p.ErrorDataReceived += (s, e) => { if (e.Data != null) diagnostics.Read(e.Data); };
        p.Exited += async (s, e) => {
            try
            {
                int code = p.ExitCode;
                await Task.Run(() => p.WaitForExit()); // Drain redirected output before describing the exit.
                Ui(() => { if (ReferenceEquals(worker, p)) { state.Disconnected(true); detail.Text = diagnostics.Describe(code); Render(); } });
            }
            catch (InvalidOperationException) { }
        };
        try { p.Start(); p.BeginOutputReadLine(); p.BeginErrorReadLine(); }
        catch { worker = null; selected = null; p.Dispose(); state.Disconnected(true); throw; }
        Render();
    }
    void Receive(string message, WorkerDiagnostics diagnostics)
    {
        if (message == "READY: OFF") {
            if (!diagnostics.Compatible) { state.Disconnected(true); detail.Text = "前後端版本不符，請完整解壓 0.3.1 ZIP。"; Send("QUIT"); Render(); return; }
            state.Connected(); if (state.DesiredOn) Send("ON"); detail.Text = "已連接。只處理所選視窗中的「允許一次」。"; }
        else if (message == "STATUS: ON" || message == "STATUS: OFF") state.Acknowledge(message == "STATUS: ON");
        else if (message == "ATTEMPT: AUTO_INVOKE_ONCE") { sent++; detail.Text = "本次已送出 " + sent + " 次核准。"; }
        else if (message.StartsWith("AUTO: WAITING")) detail.Text = "等待核准區塊離開或畫面穩定；保持開關狀態。";
        else if (message.StartsWith("AUTO: CONTINUING")) detail.Text = "已完成一次核准，繼續監聽。累計 " + sent + " 次。";
        else if (message.StartsWith("RESULT: TIMEOUT")) { state.Disconnected(true); detail.Text = "後端逾時，結果可能已生效。請先檢查 App，再重新連接。"; }
        Render();
    }
    void Send(string command)
    {
        try { if (worker == null || worker.HasExited) throw new InvalidOperationException(); worker.StandardInput.WriteLine(command); worker.StandardInput.Flush(); }
        catch { state.Disconnected(true); detail.Text = "無法聯絡後端，請重新連接。"; }
    }
    async Task Disconnect()
    {
        var old = worker; worker = null; selected = null; state.Disconnected(false);
        if (old != null)
        {
            await Task.Run(() => {
                try { if (!old.HasExited) { try { old.StandardInput.WriteLine("QUIT"); old.StandardInput.Flush(); } catch { } if (!old.WaitForExit(2500)) { old.Kill(); old.WaitForExit(); } } } catch { }
                old.Dispose();
            });
        }
    }
    async Task Exit()
    {
        if (exiting) return; exiting = true; timer.Stop(); state.Request(false); tray.Visible = false;
        await Disconnect(); panel.Close(); tray.Dispose(); if (icon != null) icon.Dispose(); timer.Dispose(); ExitThread();
    }
    void SaveSettings()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(settingsFile));
        var temp = settingsFile + ".tmp"; File.WriteAllText(temp, new JavaScriptSerializer().Serialize(settings), new UTF8Encoding(false));
        if (File.Exists(settingsFile)) File.Replace(temp, settingsFile, null); else File.Move(temp, settingsFile);
    }
    string StartupCommand => "\"" + Application.ExecutablePath + "\"";
    void ReadStartup()
    {
        refreshStartup = true;
        try { using (var key = Registry.CurrentUser.OpenSubKey(RunKey)) startup.Checked = string.Equals(key?.GetValue(RunName) as string, StartupCommand, StringComparison.OrdinalIgnoreCase); }
        catch { startup.Checked = false; startup.Enabled = false; }
        finally { refreshStartup = false; }
    }
    void ChangeStartup()
    {
        if (refreshStartup) return;
        try
        {
            using (var key = Registry.CurrentUser.CreateSubKey(RunKey))
            {
                string old = key.GetValue(RunName) as string;
                if (old != null && !string.Equals(old, StartupCommand, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Existing startup entry belongs to a different location.");
                if (startup.Checked && StartupCommand.Length > 260) throw new InvalidOperationException("Startup path is too long.");
                if (startup.Checked) key.SetValue(RunName, StartupCommand, RegistryValueKind.String);
                else key.DeleteValue(RunName, false);
            }
        }
        catch { MessageBox.Show(panel, "無法變更登入啟動。公司政策可能限制此設定，或同名啟動項目使用了另一個路徑。程式仍可手動啟動。", "Codex Auto-Accept"); }
        ReadStartup();
    }
    static bool SameWindow(TargetWindow w)
    {
        if (!IsWindow(new IntPtr(w.Hwnd))) return false;
        uint pid; GetWindowThreadProcessId(new IntPtr(w.Hwnd), out pid);
        if (pid != w.Pid) return false;
        try { using (var p = Process.GetProcessById(w.Pid)) return p.StartTime.ToUniversalTime().Ticks == w.Started; }
        catch { return false; }
    }
    static List<TargetWindow> Windows()
    {
        var windows = new List<TargetWindow>();
        EnumWindows((h, l) => {
            if (!IsWindowVisible(h)) return true;
            uint id; GetWindowThreadProcessId(h, out id);
            try
            {
                using (var p = Process.GetProcessById((int)id))
                {
                    string name = p.ProcessName;
                    if (name.StartsWith("CodexUia", StringComparison.OrdinalIgnoreCase) || name == "CodexAutoAcceptDesktop"
                        || (name.IndexOf("ChatGPT", StringComparison.OrdinalIgnoreCase) < 0 && name.IndexOf("Codex", StringComparison.OrdinalIgnoreCase) < 0)) return true;
                    var title = new StringBuilder(2048); GetWindowText(h, title, title.Capacity);
                    string path = null; try { path = p.MainModule.FileName; } catch { }
                    windows.Add(new TargetWindow { Hwnd = h.ToInt64(), Started = p.StartTime.ToUniversalTime().Ticks, Pid = (int)id, Path = path, Name = name, Title = title.ToString() });
                }
            }
            catch { }
            return true;
        }, IntPtr.Zero);
        return windows;
    }
    delegate bool EnumProc(IntPtr hwnd, IntPtr param);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc callback, IntPtr param);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hwnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int max);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll")] static extern bool DestroyIcon(IntPtr icon);
}
