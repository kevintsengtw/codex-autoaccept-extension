# Verification — 2026-10-12

- Cross-built `net48` Release with .NET SDK on macOS: zero warnings/errors.
- Audited the compiled EXE using `System.Reflection.Metadata`: managed entry point and UIA assembly references present; embedded manifest uses `asInvoker` and `uiAccess=false`; 11 native imports are restricted to window enumeration/metadata and process-token queries; no referenced UIA Invoke, setters, focus, selection, scroll, toggle, move/resize actions or network/input APIs in the audited categories.
- The supervisor starts and, on timeout, terminates only its own UIA worker. It does not obtain a target process control handle. `OpenProcess` uses query-limited access (`0x1000`), and tokens use query access (`0x0008`). Reports are bounded, append per node and preserve partial capture.
- Source reviewed for capture scope: only the explicitly selected HWND subtree is traversed. Window selection is manual. TextPattern document text is opt-in and skipped for passwords/unknown password status. No ValuePattern values, screenshots, Codex configuration writes or approval actions.
- Packaged executable/config, source, pinned build dependency lock, documentation and MIT license; archive contents and SHA-256 verified by packaging script.

Not performed: Windows runtime execution, UIA provider compatibility, company application-control policy checks, actual ChatGPT Desktop App 26.803.81509 inspection, target token checks on Windows, worker termination on a stalled Windows provider, foreground/background comparisons, or live approval handling. The API audit is a bounded static check, not a proof of all behavior. This tool deliberately never invokes an approval button.

Reproduce build and compiled API audit:

```sh
dotnet build desktop-probe/CodexUiaProbe.csproj -c Release
dotnet run --project desktop-probe/verify/ProbeAudit.csproj -- desktop-probe/bin/Release/net48/CodexUiaProbe.exe
python3 scripts/package-probe.py
```

Windows acceptance: capture baseline and visible approval in a normal-user session, check header/summary/errors, confirm the pending approval remains pending, inspect relevant parent/child nodes and declared patterns. Missing or partial data must not be interpreted as lack of UIA support.

## 0.1.1 local summary

- Added `--summarize` to analyze an existing local report without another UIA scan. A successful summary has exit code 0 independently of the original capture result.
- Ten portable summary checks passed: content exclusion, missing summary, malformed JSON line status, timeout, button filtering, Invoke declaration, unavailable patterns, adjacent text scope, complete capture and partial error counts.
- Rebuilt net48 EXE with zero warnings/errors; compiled read-only API audit passed again.
- Windows execution and actual 0.1.0 company report analysis remain unverified. Exit code 2 reported by the user establishes an incomplete result, not its underlying cause.

```sh
dotnet run --project desktop-probe/verify/SummaryTests.csproj
```

## 0.1.2 manual one-shot mode

- Kept the read-only probe and the invoking helper in separate assemblies. Read-only API audit passed for CodexUiaProbe; helper audit permits only InvokePattern.Invoke as a UI mutation and rejects other UI/input/network APIs.
- Both net48 projects cross-built with zero warnings/errors.
- Six portable confirmation-gate scenarios passed: no confirmation, cancellation/exact input, one call only, stale target, provider exception with no retry, and validation exception with no retry. Ten existing summary checks also passed.
- Source review: explicit mode, exact-label unique usable button, complete bounded scan, medium integrity checks, local context presentation, fresh scan and identity/context revalidation, final pre-invoke checks, one consumed confirmation, no retry, bounded post-observation. These reduce stale targeting; UIA lacks an atomic approval-request transaction.
- Actual Windows Invoke, company policy allowing the helper EXE, provider timing, cancellation while waiting and observation outcomes remain unverified.
- User-reported 0.1.1 Windows probe result: depth 60 yielded exit 0, zero read errors/boundaries, no node cap, one label Button candidate, one Invoke declaration, one enabled/onscreen candidate. This establishes discovery, not invocation success.

```sh
dotnet build desktop-probe/manual/CodexUiaManualInvoke.csproj -c Release
dotnet build desktop-probe/CodexUiaProbe.csproj -c Release
dotnet run --project desktop-probe/verify/ManualTests.csproj
dotnet run --project desktop-probe/verify/ProbeAudit.csproj -- desktop-probe/manual/bin/Release/net48/CodexUiaManualInvoke.exe manual
```

## 0.2.0 ON/OFF automatic mode

- User confirmed manual INVOKE ONCE removed the pending approval and Codex continued in the company environment. This is user-reported live validation of manual mode only.
- Added an explicit auto mode with terminal O/F/Space/Q controls, default OFF, normal-user integrity checks and no persisted ON setting.
- Thirteen portable state tests passed: revocation/epochs, one commit, no retry across OFF/ON, absence handling, completed original/new identities, stale scan rejection, quit and concurrent commit. Six manual-gate and ten summary checks passed.
- Cross-built both Windows EXEs with zero warnings/errors. API audits passed for the read-only probe and the helper (only InvokePattern.Invoke allowed for UI mutation).
- Original-element removal is required for successful auto observation; enabled/offscreen changes alone are ambiguous and switch OFF. Consumed target keys persist across OFF/ON for the current process; this can conservatively block a new prompt reusing identical UI metadata.
- Automatic Windows execution, company helper execution policy, continuous background polling, actual OFF responsiveness and multiple real approval requests remain unverified. There are no command deny rules or per-chat binding in this UIA prototype.

```sh
dotnet run --project desktop-probe/verify/AutoTests.csproj
```

## User-reported company Windows auto-mode verification — 2026-10-12

Target: ChatGPT Desktop App (Codex) 26.803.81509, standard-user execution, UIA tool 0.2.0.

The user confirmed:

- OFF leaves the approval pending for manual handling.
- Switching ON invokes “允許一次” automatically.
- A second approval is handled normally.
- Switching OFF again stops automatic approvals.

This supersedes the earlier unverified entries for basic automatic invocation, consecutive approvals and ON/OFF behavior in this specific company environment. It is user-reported live validation, not direct agent observation or a general compatibility guarantee. Scan-time OFF races, provider hangs, ambiguous outcomes, terminal shutdown, long-running sessions, minimization, other App versions and multi-chat/window behavior remain unverified. Command rules and per-chat binding remain unimplemented.

Only documentation was updated after this report; the tested 0.2.0 ZIP and executable bytes were preserved.

## 0.2.1 continuous ON correction

The user clarified that 0.2.0 switches OFF after an approval. This supersedes the earlier interpretation of the 0.2.0 live report as successful continuous automatic operation. The implementation indeed switched OFF when a retained/hidden button did not become a stale element within five seconds.

- Removed normal post-invoke automatic OFF and transient scan-error OFF. ON remains ON while waiting/rescanning; failed status logging and provider timeouts can still stop the helper.
- Accepts a stale original element or an offscreen original button in a visible, non-minimized target window as a lifecycle boundary. Disabled visible buttons count as present. Incomplete scans and hidden/minimized windows cannot advance absence detection.
- Resets dedupe only at a verified lifecycle boundary, permitting new approvals that reuse the same UI identity. An OFF/ON toggle alone never retries a consumed attempt.
- Portable lifecycle tests cover twenty consecutive same-identity approvals without another ON action, no duplicate attempt within a cycle, waiting with ON preserved, generation revocation, absence detection and concurrent attempts. Manual and summary tests and API audits passed.
- Windows company validation of 0.2.1 remains pending. UIA lifecycle observations are not protocol request IDs; a boundary that cannot be observed will keep the tool waiting.
