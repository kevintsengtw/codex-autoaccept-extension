using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Automation;

internal static class ManualProgram
{
    sealed class ManualRefusalException : InvalidOperationException
    { public ManualRefusalException(string message) : base(message) { } }
    sealed class Candidate
    {
        public AutomationElement Element;
        public string Id, ParentId, ContextHash;
        public string[] Context;
    }
    sealed class Pending { public AutomationElement Element; public int Depth; }
    static IntPtr hwnd;
    static int targetPid, depth = 60, nodes = 3000, timeout = 45;
    static long processStarted;
    static string rootId, log;
    static volatile bool invocationStarted;
    static int Main(string[] args)
    {
        Console.OutputEncoding = new UTF8Encoding(false);
        try
        {
            for (int i = 0; i < args.Length; i++)
            {
                string key = args[i];
                if (++i >= args.Length) throw new ArgumentException("Missing value.");
                int n;
                switch (key)
                {
                    case "--hwnd": hwnd = new IntPtr(long.Parse(args[i], CultureInfo.InvariantCulture)); break;
                    case "--max-depth": n = int.Parse(args[i]); if (n < 1 || n > 100) throw new ArgumentException("Invalid depth."); depth = n; break;
                    case "--max-nodes": n = int.Parse(args[i]); if (n < 1 || n > 10000) throw new ArgumentException("Invalid node budget."); nodes = n; break;
                    case "--timeout": n = int.Parse(args[i]); if (n < 5 || n > 120) throw new ArgumentException("Invalid timeout."); timeout = n; break;
                    default: throw new ArgumentException("Unknown option.");
                }
            }
            if (hwnd == IntPtr.Zero || !IsWindow(hwnd)) throw new ArgumentException("A live target HWND is required. Start via Run-Manual-Once.cmd.");
            uint pid; GetWindowThreadProcessId(hwnd, out pid); targetPid = (int)pid;
            string probeLevel = Integrity(Process.GetCurrentProcess().Id), targetLevel = Integrity(targetPid);
            Console.WriteLine("INTEGRITY: probe={0}; target={1}", probeLevel, targetLevel);
            if (probeLevel != "medium" || targetLevel != "medium")
                throw new ManualRefusalException("Both tool and target must have medium (standard-user) integrity. No elevation is attempted.");
            using (var process = Process.GetProcessById(targetPid)) processStarted = process.StartTime.ToUniversalTime().Ticks;
            var directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CodexUiaProbe");
            Directory.CreateDirectory(directory);
            log = Path.Combine(directory, "manual-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N") + ".txt");
            Status("MODE: MANUAL SINGLE INVOKE; no automated approvals or retries.");
            Console.WriteLine("Visible context is shown locally only. Log records statuses, not UI text.");
            var title = new StringBuilder(2048); GetWindowText(hwnd, title, title.Capacity);
            Console.WriteLine("Target HWND=0x{0:X}, PID={1}, title={2}", hwnd.ToInt64(), targetPid, Line(title.ToString()));
            var candidate = Timed(Scan, "initial scan");
            Console.WriteLine("Exact button label: 允許一次; enabled, onscreen, Invoke available.");
            Console.WriteLine("Immediate-parent context (partial view; review the pending operation in ChatGPT itself):");
            foreach (string line in candidate.Context) Console.WriteLine("  " + line);
            Console.WriteLine("This will approve the currently displayed operation once. Confirm its command in ChatGPT before continuing.");
            Console.Write("Type INVOKE ONCE exactly to confirm, or Enter/anything else to cancel: ");
            var gate = new ManualGate();
            if (!gate.Confirm(Console.ReadLine())) { Status("RESULT: CANCELLED; nothing invoked."); return 0; }
            var fresh = Timed(Scan, "revalidation scan");
            bool unchanged = Same(candidate, fresh);
            if (!unchanged) { Status("RESULT: TARGET_CHANGED; nothing invoked. Rerun and review again."); return 4; }
            Timed(() =>
            {
                gate.Execute(() => ValidWindow() && Id(AutomationElement.FromHandle(hwnd)) == rootId && Exact(fresh.Element) && Id(fresh.Element) == candidate.Id
                    && ParentId(fresh.Element) == candidate.ParentId && Context(fresh.Element).Item1 == candidate.ContextHash,
                    () =>
                    {
                        object pattern;
                        if (!fresh.Element.TryGetCurrentPattern(InvokePattern.Pattern, out pattern))
                            throw new ManualRefusalException("Invoke became unavailable; nothing invoked.");
                        // Persist attempt BEFORE the one call. A hang/error can mean the provider still acted.
                        Status("ATTEMPT: INVOKE_ONCE; user confirmed.");
                        invocationStarted = true;
                        ((InvokePattern)pattern).Invoke(); // Sole UI mutation site; gate has already been consumed.
                    });
                return true;
            }, "single invocation");
            Status("INVOKE: RETURNED; this alone does not prove approval succeeded.");
            string observed = Timed(() => Observe(fresh), "post-invoke observation");
            Status("OBSERVATION: " + observed);
            Console.WriteLine("Check ChatGPT: did the approval disappear and the operation continue? Do not retry automatically.");
            Console.WriteLine("Status log (no UI content): " + log);
            return observed == "BUTTON_UNAVAILABLE_OR_HIDDEN" ? 0 : 5;
        }
        catch (Exception e)
        {
            Console.WriteLine(invocationStarted ? "RESULT: UNKNOWN_AFTER_ATTEMPT; check ChatGPT before any new test. NO RETRY." : "RESULT: NOT_INVOKED.");
            try { Status("ERROR_TYPE: " + e.GetType().Name); } catch { Console.WriteLine("Status log unavailable."); }
            // Exception messages can contain UI information; only print the type and our own fixed guidance.
            var cause = e.GetBaseException();
            Console.WriteLine("Error type: " + cause.GetType().Name);
            if (cause is ManualRefusalException) Console.WriteLine("Reason: " + cause.Message);
            Console.WriteLine(invocationStarted ? "Provider may have acted even if it reported an error." : "Requires exactly one exact-label button, a complete scan and an unchanged target/context.");
            return invocationStarted ? 5 : 4;
        }
    }
    static T Timed<T>(Func<T> action, string stage)
    {
        var task = Task.Run(action);
        if (!task.Wait(timeout * 1000))
        {
            Status("RESULT: TIMEOUT during " + stage + (stage == "single invocation" || invocationStarted ? "; outcome UNKNOWN; NO RETRY." : "; nothing invoked."));
            Console.WriteLine("Check ChatGPT before repeating this test.");
            Environment.Exit(3); // Ends this process and background UIA work; never leaves an invocation worker alive.
        }
        return task.GetAwaiter().GetResult();
    }
    static Candidate Scan()
    {
        if (!ValidWindow()) throw new ManualRefusalException("Target window changed.");
        var root = AutomationElement.FromHandle(hwnd);
        string currentRoot = Id(root);
        if (rootId == null) rootId = currentRoot;
        else if (rootId != currentRoot) throw new ManualRefusalException("Root changed.");
        var stack = new Stack<Pending>(); var seen = new HashSet<string>(); var found = new List<Candidate>(); int count = 0;
        stack.Push(new Pending { Element = root });
        while (stack.Count > 0)
        {
            if (count >= nodes) throw new ManualRefusalException("Node budget reached.");
            var item = stack.Pop(); var el = item.Element;
            if (!seen.Add(Id(el))) throw new ManualRefusalException("Tree repeated an element.");
            count++;
            if (Exact(el))
            {
                var context = Context(el);
                found.Add(new Candidate { Element = el, Id = Id(el), ParentId = ParentId(el), ContextHash = context.Item1, Context = context.Item2 });
            }
            var child = TreeWalker.RawViewWalker.GetFirstChild(el);
            if (child != null && item.Depth >= depth) throw new ManualRefusalException("Depth budget reached.");
            int childCount = 0;
            while (child != null)
            {
                if (++childCount > nodes) throw new ManualRefusalException("Sibling budget reached.");
                stack.Push(new Pending { Element = child, Depth = item.Depth + 1 });
                child = TreeWalker.RawViewWalker.GetNextSibling(child);
            }
        }
        Console.WriteLine("Scan complete: nodes={0}, exact usable candidates={1}", count, found.Count);
        if (found.Count != 1) throw new ManualRefusalException("Requires exactly one candidate.");
        return found[0];
    }
    static bool Exact(AutomationElement el)
    {
        var c = el.Current;
        return c.ControlType == ControlType.Button && c.Name == "允許一次" && c.IsEnabled && !c.IsOffscreen
            && (bool)el.GetCurrentPropertyValue(AutomationElement.IsInvokePatternAvailableProperty);
    }
    static bool Same(Candidate a, Candidate b)
    { return a.Id == b.Id && a.ParentId == b.ParentId && a.ContextHash == b.ContextHash; }
    static string Id(AutomationElement el) { return string.Join(".", el.GetRuntimeId()); }
    static string ParentId(AutomationElement el) { var p = TreeWalker.RawViewWalker.GetParent(el); return p == null ? "" : Id(p); }
    static Tuple<string, string[]> Context(AutomationElement el)
    {
        var parent = TreeWalker.RawViewWalker.GetParent(el);
        if (parent == null) throw new ManualRefusalException("Missing parent context.");
        var display = new List<string>(); var data = new StringBuilder();
        var elements = new List<AutomationElement> { parent };
        var child = TreeWalker.RawViewWalker.GetFirstChild(parent);
        while (child != null)
        {
            if (elements.Count >= 65) throw new ManualRefusalException("Context too large to validate.");
            elements.Add(child); child = TreeWalker.RawViewWalker.GetNextSibling(child);
        }
        foreach (var e in elements)
        {
            var c = e.Current;
            string name = c.IsPassword ? "[password control omitted]" : (c.Name ?? "");
            // Full local fingerprint; console is clipped. Never stores context text in the status log.
            data.Append(Id(e)).Append('|').Append(c.ControlType.Id).Append('|').Append(name.Length).Append(':').Append(name).Append('\n');
            display.Add(c.ControlType.ProgrammaticName + ": " + Line(name.Length > 200 ? name.Substring(0, 200) + " [truncated]" : name));
        }
        using (var sha = SHA256.Create())
            return Tuple.Create(Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(data.ToString()))), display.ToArray());
    }
    static string Observe(Candidate candidate)
    {
        var until = DateTime.UtcNow.AddSeconds(5);
        while (DateTime.UtcNow < until)
        {
            if (!ValidWindow()) return "WINDOW_CHANGED; APPROVAL_OUTCOME_UNKNOWN";
            try
            {
                if (Id(candidate.Element) != candidate.Id) return "ELEMENT_CHANGED; APPROVAL_OUTCOME_UNKNOWN";
                var c = candidate.Element.Current;
                if (!c.IsEnabled || c.IsOffscreen || c.Name != "允許一次") return "BUTTON_UNAVAILABLE_OR_HIDDEN";
            }
            catch (ElementNotAvailableException) { return "BUTTON_UNAVAILABLE_OR_HIDDEN"; }
            Thread.Sleep(250);
        }
        return "BUTTON_STILL_AVAILABLE; APPROVAL_OUTCOME_UNKNOWN";
    }
    static bool ValidWindow()
    {
        if (!IsWindow(hwnd)) return false;
        uint pid; GetWindowThreadProcessId(hwnd, out pid);
        if (pid != targetPid) return false;
        using (var process = Process.GetProcessById(targetPid))
            return process.StartTime.ToUniversalTime().Ticks == processStarted;
    }
    static string Line(string s) { return s.Replace("\r", " ").Replace("\n", " ").Replace("\t", " "); }
    static void Status(string message)
    {
        Console.WriteLine(message);
        if (log != null) File.AppendAllText(log, DateTime.UtcNow.ToString("o") + " " + message + "\n", new UTF8Encoding(false));
    }
    static string Integrity(int pid)
    {
        IntPtr process = OpenProcess(0x1000, false, pid), token = IntPtr.Zero, buffer = IntPtr.Zero;
        if (process == IntPtr.Zero) return "unavailable";
        try
        {
            if (!OpenProcessToken(process, 0x0008, out token)) return "unavailable";
            int length; GetTokenInformation(token, 25, IntPtr.Zero, 0, out length);
            if (length <= 0) return "unavailable";
            buffer = Marshal.AllocHGlobal(length);
            if (!GetTokenInformation(token, 25, buffer, length, out length)) return "unavailable";
            IntPtr sid = Marshal.ReadIntPtr(buffer);
            byte count = Marshal.ReadByte(GetSidSubAuthorityCount(sid));
            int rid = Marshal.ReadInt32(GetSidSubAuthority(sid, (uint)(count - 1)));
            return rid == 0x2000 ? "medium" : "other";
        }
        finally { if (buffer != IntPtr.Zero) Marshal.FreeHGlobal(buffer); if (token != IntPtr.Zero) CloseHandle(token); CloseHandle(process); }
    }
    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hwnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int max);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr process, uint access, out IntPtr token);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool GetTokenInformation(IntPtr token, int infoClass, IntPtr buffer, int length, out int returnLength);
    [DllImport("advapi32.dll")] static extern IntPtr GetSidSubAuthorityCount(IntPtr sid);
    [DllImport("advapi32.dll")] static extern IntPtr GetSidSubAuthority(IntPtr sid, uint index);
}
