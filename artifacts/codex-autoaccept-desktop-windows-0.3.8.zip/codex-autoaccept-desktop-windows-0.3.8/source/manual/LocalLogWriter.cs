using System;
using System.IO;
using System.Text;
using System.Threading;

internal sealed class LogWriteFailure : IOException
{
    public readonly string Stage;
    public readonly int NativeError;
    public LogWriteFailure(string stage, IOException cause) : base("Local log write failed.", cause)
    { Stage = stage; NativeError = cause.HResult & 0xffff; }
}

internal static class LocalLogWriter
{
    static void AppendMain(string path, string block)
    {
        try { File.AppendAllText(path, block, new UTF8Encoding(false)); }
        catch (IOException e) { throw new LogWriteFailure("MAIN_APPEND", e); }
    }
    public static void AppendWithSummaryFallback(string path, string block, string summaryText,
        Func<LogWriteFailure, string> describe, Action<LogWriteFailure> warn)
    {
        try { Append(path, block, summaryText); }
        catch (LogWriteFailure e)
        {
            if (e.Stage == "MAIN_APPEND") throw;
            // The complete record already exists. Persist the summary warning in
            // the authoritative main log; never replay the original append/action.
            string warning = describe(e);
            if (warning != null) AppendMain(path, warning);
            warn(e);
        }
    }
    public static void Append(string path, string block, string summaryText)
    {
        // Never retry the append: a partial write must not duplicate evidence.
        AppendMain(path, block);
        string summary = Path.ChangeExtension(path, null) + "-summary.txt", temp = summary + ".tmp";
        try { File.WriteAllText(temp, summaryText, new UTF8Encoding(true)); }
        catch (IOException e) { throw new LogWriteFailure("SUMMARY_WRITE", e); }
        // Readers/scanners can briefly deny delete-sharing on Windows. Only
        // retry the atomic summary replacement, never an approval or main append.
        for (int attempt = 0; ; attempt++)
        {
            try
            {
                if (File.Exists(summary)) File.Replace(temp, summary, null);
                else File.Move(temp, summary);
                return;
            }
            catch (IOException e)
            {
                int error = e.HResult & 0xffff;
                if ((error != 32 && error != 33) || attempt >= 4)
                    throw new LogWriteFailure("SUMMARY_REPLACE", e);
                Thread.Sleep(100);
            }
        }
    }
}
