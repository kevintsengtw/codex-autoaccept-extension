# Codex Auto-Accept Desktop 0.3.2

Windows 系統匣常駐版。雙擊 EXE 即可使用，**不需開啟或保留 Windows Terminal**。每次啟動皆為 OFF，由你用滑鼠開啟；不保存 ON 到下次啟動。

## 0.3.2：權限資料與啟動檢查

0.3.1 的權限預檢只接受 backend 和 App token RID 精確為 `0x2000`，並把查詢不到資料當成不足，因此可能在開始 UIA 前就退出。0.3.2 將權限資料查詢與 UIA 的實際存取能力分開：

- 一般／較低／medium-plus 範圍不因不等於單一數字而提前退出。medium-plus 等跨層級操作仍可能被 Windows UIPI 阻擋，不代表可以控制。
- 查詢不到 token 時顯示 `unavailable` 和查詢階段／Win32 錯誤碼，仍允許正常初始化；實際 UIA 讀取和 Invoke 由 Windows 執行權限檢查，錯誤時不連點。
- 已確認的 high／system 工具或目標仍不啟用，請保持一般使用者啟動；不增加 UIAccess、不要求 administrator、不變更公司政策。
- 本機 GUI 會顯示「後端權限／App 權限」；退出錯誤也保留這些資訊，不再只有「目標已變更或權限不符」。

若還無法連接，在公司允許描述診斷資訊的前提下，只需告知權限層級及查詢階段／錯誤碼，無需提供 PID、標題、命令或路徑。當前還沒有公司實際 token 查詢結果，不能把既有回報解讀成確定需要提權。

另外加入 UIA 狀態訊息，區分 `MINIMIZED`、`ROOT_OFFSCREEN`、`BUTTON_OFFSCREEN`、`BUTTON_NOT_READY` 和找不到核准按鈕。這能協助在本機分辨背景遮蔽的原因，**不代表背景遮蔽問題已修正或通過驗證**。

## 0.3.1 修正後端啟動與操作順序

0.3.0 的隱藏後端在啟動時設定 `Console.OutputEncoding`；.NET Framework 會因此呼叫 Console API，在沒有 Console 的程序中可失敗，且原本未被初始化的錯誤處理捕捉。0.3.1 改用標準輸入／輸出的 UTF-8 StreamReader／StreamWriter，不再呼叫 Console 編碼 setter。這不是按鈕順序造成的問題。

新版按鈕由左至右為 **「1. 選擇 App 視窗」→「2. 開啟 ON」→「重新連接」**。尚未連接完成時，ON 按鈕與系統匣 ON 選項會停用，不能先啟用不存在的後端。重新連接會優先重用本次已選且仍有效的視窗，不依賴儲存的 App 路徑是否可讀。

前後端會比對版本。後端若停止，介面顯示退出碼、錯誤類型及固定分類，不保存或顯示原始 stderr 中可能包含的公司路徑。完整解壓同一版 ZIP，不能只換前端 EXE；後端為 `CodexUiaManualInvoke.exe`。

更新：在舊版系統匣選「退出」，完整解壓新版到新的目錄，再雙擊新版 EXE。可以保留 App 與等待核准畫面，不需刪除本機設定。若舊版啟用了登入啟動，先在舊版取消，再到新版設定，以免下次登入啟動舊版。

## 第一次使用

1. 完整解壓 ZIP 到公司允許執行的固定使用者目錄，保留所有 EXE／config 在同一資料夾。不要在 ZIP 裡直接執行。
2. 如果舊版 Terminal 自動模式還在執行，先用 Q 結束，避免兩套工具同時核准。
3. 以一般使用者身分雙擊 **`CodexAutoAcceptDesktop.exe`**。第一次會開啟設定視窗。
4. 開啟公司 ChatGPT Desktop App，按「選擇 App 視窗」，人工指定正確視窗。工具會記住 App 執行檔路徑，供後續重新連接；不保存聊天標題或 ON 狀態。若公司阻擋路徑讀取，本次仍可選取使用，但下次要重選。
5. 按「開啟 ON」，看到 `ON · 自動核准中` 後即可關閉設定視窗。這裡的關閉會留在系統匣，**不會停止程式**。

執行條件：Windows 10／11、.NET Framework 4.8／4.8.1，以及公司允許前端 EXE 與核准後端 EXE 執行。前後端均使用 asInvoker，不要求管理員權限；權限資料不是對 UIA 存取能力的保證。EXE 未經 Authenticode 簽署，SHA-256 只核對成品內容。

## 日常操作

- 右下角系統匣有 A 圖示；Windows 可能將它放在「顯示隱藏圖示」裡。
- **右鍵 → 開啟 ON／關閉 OFF**：持續自動核准的開關。
- **雙擊圖示／右鍵 → 開啟設定**：查看開關、目標與核准計數。
- **右鍵 → 退出**：停止後端並退出前端。關閉設定視窗只會隱藏視窗。
- 關閉再開啟程式，一律回到 OFF，符合使用者指定的啟動方式。
- 第二次啟動相同程式時不建立另一個常駐個體，會提醒到系統匣查看。

一般使用時不需要點 CMD，也不需保留任何 console 視窗。`CodexUiaManualInvoke.exe` 是隱藏執行的後端，請保留它與 config；不要直接雙擊該後端。

圖示為綠色表示後端已回報 ON；灰色表示 OFF／等待 App；橘色表示後端已停止、需要處理。切 OFF 時可能短暫顯示「停止中」，收到後端確認才顯示 OFF。**已承諾開始的 Invoke 可能仍完成，OFF 無法撤回它。**

## App 重新開啟與後端停止

App 尚未開啟時，工具會等待記住的執行檔路徑。找到唯一符合的可見視窗後會自動連接。找到多個視窗時，要求人工指定，不隨意挑選；無法讀到路徑時只能人工重選。

如果在本次程式執行中已開啟 ON，App 正常關閉／重開後仍會保留本次的 ON 意圖並重新連接。**這與重開 Auto-Accept 程式不同：重開工具一律 OFF。**

後端逾時或異常結束時，前端會顯示暫停，不把「想要 ON」當成「正在 ON」。不自動重新送出不確定的核准；先查看 App，再按「重新連接」（回到 OFF），最後由你開啟 ON。舊 worker 的延遲訊息不會更新新 worker 的狀態。

## 登入 Windows 時啟動

設定視窗可勾選「登入 Windows 時啟動（啟動後仍為 OFF）」。預設不替你勾選。

此選項只寫入目前使用者的 `HKCU\Software\Microsoft\Windows\CurrentVersion\Run` 中 `CodexAutoAcceptDesktop` 這一個值，不建立服務或管理員排程。如果公司政策禁止登錄設定，會顯示失敗並恢復實際登錄狀態；工具仍可手動啟動。註冊成功不保證公司政策或 Windows 啟動應用程式設定一定允許登入時執行。

開啟登入啟動前請先放到固定目錄；搬移／更新目錄前先在舊版取消勾選，再到新版重新設定。同名啟動值指向其他路徑時不會直接覆寫，避免誤刪既有設定。

## 核准範圍

沿用公司已驗證的 0.2.1 UIA 核心：處理所選視窗中唯一、精確顯示「允許一次」、已啟用且可見的 Invoke Button。保持 ON 處理連續請求；每個核准週期最多嘗試一次，核准前重掃並比對視窗、控制項及局部內容。

仍不具有命令白名單／拒絕規則或聊天 ID 綁定。切換所選 App 視窗中的聊天也會改變監聽對象。隱藏／最小化整個 App 時不把畫面隱藏當成請求完成；不能辨識生命週期的情況會等待，避免連點。

## 本機資料與移除

- `%LOCALAPPDATA%\CodexAutoAcceptDesktop\settings.json`：所選 App 執行檔路徑；不含 ON 狀態。
- `%LOCALAPPDATA%\CodexUiaProbe\auto-*.txt`：時間及固定狀態；不保存命令、對話或 UI 指紋。
- 設定視窗／選擇器可能顯示 App 標題，僅用於公司本機辨識。
- 不需要把報告帶出公司。若允許描述測試結果，只需告知 GUI 操作是否符合下述驗收。

移除：先取消登入啟動 → 系統匣右鍵退出 → 刪除解壓目錄；需要時另刪上述本機資料目錄。不修改 ChatGPT 安裝，也不需還原 App。

## 本次驗證與公司驗收

已交叉建置 net48 成品、測試前端狀態機／核心核准流程、檢查前端是 Windows GUI subsystem、前後端 manifest 為 asInvoker。**macOS 無法完成 WinForms 系統匣、登入啟動、實際跨程序控制及 Windows 高 DPI 的操作驗證；0.3.2 仍需公司 Windows 實測。** 0.2.1 核心的持續 ON 及 F 停止已由使用者確認，不能直接代表新版 GUI 已實測。

建議依序驗證：

1. 雙擊 EXE，沒有 Terminal 出現，初始 OFF。
2. 選擇 App → ON → 關閉設定視窗；連續三次「允許一次」正常自動核准。
3. 從系統匣切 OFF，下一次核准保留人工處理。
4. 退出工具再重開，仍為 OFF。
5. App 關閉／重開能重新連接；多視窗需人工選擇。
6. 選擇性測試登入啟動；若公司政策不允許，保留錯誤，不改走提權。

原始碼在 ZIP 的 `source/tray/`；可用 `dotnet build source/tray/CodexAutoAcceptDesktop.csproj -c Release` 建置。診斷用 CLI／唯讀工具仍保留，說明在 `diagnostics/README.md`。

技術來源：[Microsoft NotifyIcon](https://learn.microsoft.com/en-us/dotnet/desktop/winforms/controls/notifyicon-component-windows-forms)、[使用者 Run 登入啟動](https://learn.microsoft.com/en-us/windows/win32/setupapi/run-and-runonce-registry-keys)。
