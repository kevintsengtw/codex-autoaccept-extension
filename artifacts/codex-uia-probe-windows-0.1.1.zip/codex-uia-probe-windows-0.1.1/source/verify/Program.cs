using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Text;

if (args.Length != 1) throw new ArgumentException("Pass the built CodexUiaProbe.exe path.");
var bytes = File.ReadAllBytes(args[0]);
using var pe = new PEReader(new MemoryStream(bytes));
if (!pe.HasMetadata || pe.PEHeaders.CorHeader.EntryPointTokenOrRelativeVirtualAddress == 0)
    throw new Exception("Expected managed executable with entry point.");
var metadata = pe.GetMetadataReader();
var forbidden = new HashSet<string> {
    "Invoke", "SetFocus", "SetValue", "Move", "Resize", "Select", "AddToSelection", "RemoveFromSelection",
    "Expand", "Collapse", "Scroll", "ScrollIntoView", "Toggle", "SetWindowVisualState", "SetForegroundWindow",
    "SendInput", "SendKeys", "mouse_event", "keybd_event", "SetCursorPos"
};
foreach (var handle in metadata.MemberReferences)
{
    var member = metadata.GetMemberReference(handle);
    var name = metadata.GetString(member.Name);
    if (member.Parent.Kind == HandleKind.TypeReference)
    {
        var type = metadata.GetTypeReference((TypeReferenceHandle)member.Parent);
        string ns = metadata.GetString(type.Namespace);
        if (ns.StartsWith("System.Windows.Automation") && (forbidden.Contains(name) || name.StartsWith("set_")))
            throw new Exception("UIA action/setter referenced: " + name);
        if (ns.StartsWith("System.Net") || ns == "System.Windows.Forms" && metadata.GetString(type.Name) == "SendKeys")
            throw new Exception("Unexpected network/input API: " + ns + "." + name);
    }
}
var native = new Dictionary<string, string> {
    ["EnumWindows"]="user32.dll", ["IsWindowVisible"]="user32.dll", ["IsWindow"]="user32.dll",
    ["GetWindowText"]="user32.dll", ["GetWindowThreadProcessId"]="user32.dll",
    ["OpenProcess"]="kernel32.dll", ["CloseHandle"]="kernel32.dll",
    ["OpenProcessToken"]="advapi32.dll", ["GetTokenInformation"]="advapi32.dll",
    ["GetSidSubAuthorityCount"]="advapi32.dll", ["GetSidSubAuthority"]="advapi32.dll"
};
int imports = 0;
foreach (var handle in metadata.MethodDefinitions)
{
    var method = metadata.GetMethodDefinition(handle);
    var import = method.GetImport();
    if (import.Module.IsNil) continue;
    string name = metadata.GetString(import.Name);
    string module = metadata.GetString(metadata.GetModuleReference(import.Module).Name);
    if (!native.TryGetValue(name, out var allowed) || allowed != module)
        throw new Exception("Unexpected native API: " + module + "!" + name);
    imports++;
}
if (imports != native.Count) throw new Exception("Unexpected native import count.");
string raw = Encoding.UTF8.GetString(bytes);
if (!raw.Contains("level=\"asInvoker\" uiAccess=\"false\"")) throw new Exception("Expected embedded standard-user manifest.");
var refs = metadata.AssemblyReferences.Select(h => metadata.GetString(metadata.GetAssemblyReference(h).Name)).ToHashSet();
if (!refs.Contains("UIAutomationClient") || !refs.Contains("UIAutomationTypes")) throw new Exception("Missing UIA references.");
if (refs.Any(r => r.StartsWith("System.Net"))) throw new Exception("Unexpected networking assembly.");
Console.WriteLine("PASS: managed EXE, UIA references, embedded asInvoker manifest, 11 allowlisted native read APIs, no listed UI/input action references.");
Console.WriteLine("This audit checks API references, not Windows runtime/provider behavior or all possible side effects.");
