# Codex Windows UIA Probe 0.1.1

公司 Windows 環境用的唯讀探測工具，目標是確認 ChatGPT Desktop App（Codex）`26.803.81509` 的核准介面是否提供可用的 Windows UI Automation 資訊。這個版本號由使用者提供，不代表工具已在該版本實測。

**不點擊、不送鍵、不呼叫 Invoke、不核准、不提權、不修改 App／Codex 設定，也不連網。** 只讀取你指定視窗的控制項樹、程序版本和權限層級，在本機寫入報告。探測時會啟用 UIA 查詢；目標 App 的 accessibility provider 可能因此開始產生控制項資料，但工具不更改其 accessibility 啟動設定。

## 0.1.1：本機摘要，不需送出報告

完成掃描後，畫面及 `.summary.txt` 會顯示權限層級、節點數、可能核准按鈕數、Invoke 宣告數、相鄰可讀文字數、讀取錯誤、失效控制項及掃描限制。摘要不包含控制項 Name、命令、路徑、對話或原始錯誤訊息。完整報告仍留在本機，不需要帶出公司。

若你已有 0.1.0 的報告，不必重新觸發核准，可用新 EXE 在公司電腦讀取既有報告：

```powershell
.\CodexUiaProbe.exe --summarize "既有報告的完整路徑.jsonl"
```

此模式只讀取本機報告、顯示摘要，不使用 UIA、不重寫舊檔。Exit code 0 表示摘要成功顯示，不表示舊的探測完整。

`Probe exit code: 2` 是 **部分結果**，不代表 EXE 被阻擋或 UIA 不可用。摘要裡的 `Read errors`、`Depth boundaries reached`、`Node budget reached` 可區分原因；`stale-element exceptions` 可能來自畫面重繪。只顯示 `COMException` 等一般錯誤時，無法單憑錯誤類別判定為權限不足。

`Approval label BUTTON candidates` 只計算 Button 類型的文字匹配；`Candidates declaring Invoke` 只記錄 provider 宣告，未實際操作。`readable adjacent non-button labels/text` 只表示同父層有可讀文字，不保證那些文字是命令內容。如果需要討論結果，在公司允許的前提下，只需描述摘要中的數字與狀態，不必傳送完整報告。

## 執行條件與成品

- Windows 10／11，已安裝 .NET Framework 4.8 或 4.8.1。這是 Windows 的 .NET Framework，與 .NET 8／9／10 runtime 不同。
- 使用一般使用者身分，與 Codex App 位於同一個互動式桌面。manifest 為 `asInvoker`、`uiAccess=false`，不要求 administrator。
- 解壓縮後直接執行 EXE，無需 Node.js、Python、PowerShell 腳本、VS2022 或下載 NuGet。建置才需要 SDK／NuGet。
- 公司應允許這支自製 EXE 及其唯讀 worker 子程序啟動。免安裝不代表公司一定允許執行；若端點防護阻擋，保留錯誤交由公司處理。
- EXE 未經 Authenticode 簽署；SHA-256 僅用於核對檔案。缺少 runtime 或公司阻擋時，不要改走提權流程，先記錄錯誤。

ZIP 裡的 EXE 是在 macOS 用 .NET SDK 交叉建置的 Windows .NET Framework 成品。**尚未在 Windows／公司 Codex App 執行，屬於探測測試版。**

## 建議的兩次探測

先開啟一般權限的 Codex App，再執行工具。不要用管理員 VS2022 或管理員 Windows Terminal 開啟探測工具。

### 1. 一般畫面

1. 將 ZIP 解壓到公司允許執行的使用者目錄，保留 EXE 和 `.exe.config` 在同一資料夾。
2. 雙擊 `Run-Probe.cmd`，或在一般權限 PowerShell 執行：

   ```powershell
   .\CodexUiaProbe.exe
   ```

3. 工具列出候選視窗，包括 HWND、PID、程序名稱、標題。輸入對應 **Codex App** 的編號；候選只是名稱篩選，也可能包含 VS Code 或 Terminal，請人工確認。Enter 可取消。
4. 工具有 5 秒準備時間。可以切回 Codex App，保持視窗展開。
5. 結束後會顯示 `.jsonl` 和 `.jsonl.txt` 報告的完整路徑。預設保存在 `%LOCALAPPDATA%\CodexUiaProbe`，每次產生新檔。

### 2. 等待「允許一次」的畫面

1. 在測試專案觸發一個你本來就會測試的核准操作，讓核准區塊留在畫面上。
2. 再執行上述工具並選取相同 App 視窗，先不要按「允許一次」。
3. 探測結束後，核准仍交由你手動處理。
4. 如果報告的 Name 看不到命令內容，可以加 `--include-text` 再探測一次：

   ```powershell
   .\CodexUiaProbe.exe --include-text
   ```

`--include-text` 額外讀取 TextPattern，最多每個控制項 2048 字元；已標示密碼的控制項及無法確認密碼狀態的控制項不讀取文字。不讀 ValuePattern 的值、不擷取圖片、不讀磁碟上的對話資料。

## 指定視窗及排除問題

```powershell
# 只列出候選，不使用 UIA 探測
.\CodexUiaProbe.exe --list

# 候選中沒有 App 時，列出所有可見的頂層視窗（可能列出其他 App 的標題）
.\CodexUiaProbe.exe --list --list-all

# 換成清單裡的實際 HWND；output 請使用新檔名
.\CodexUiaProbe.exe --hwnd 0x1234 --output .\approval.jsonl

# Raw view 太多內容或太慢時，另存一份 Control view 比較
.\CodexUiaProbe.exe --view control
```

視窗關閉重開後 HWND 可能改變，需重新列出。工具預設用 Raw view，保留父子關係、AutomationId、ClassName、FrameworkId、ControlType、RuntimeId、Enabled、Offscreen、Bounds 及支援的 Pattern；控制項 Name 最多 1024 字元，截斷會標記。

最多 3000 個控制項、深度 30、worker 執行 45 秒。可用 `--max-nodes`、`--max-depth`、`--timeout` 調整；完整範圍見 `--help`。達到限制、控制項失效或錯誤時會標記不完整。UIA 卡住時，只終止工具自己的 worker，保留先前已寫入的報告，不終止 Codex。逾時中斷的最後一行可能不是完整 JSON，文字報告會標記。

Exit code：`0` 完成／列出／取消、`1` 啟動或參數錯誤、`2` 不完整、`3` 逾時。若 worker 被公司阻擋，可能只產生空的或不完整報告；請一併記錄畫面錯誤。視窗正在重繪時，報告是逐項讀取的快照，不保證所有節點來自同一瞬間。

## 如何判讀

- `header.probeIntegrity` 和 `targetIntegrity` 應為 `medium`（一般使用者）。`unavailable` 表示無法查詢，不能當成 medium。
- `targetProcess.fileVersion` 是視窗所屬 EXE 的版本，可能與 App 設定顯示的產品版本不同；請一併提供 App 裡的 `26.803.81509`。
- `approvalLabelHint=true` 只表示 Name 含已知文字，不證明它是真正的核准按鈕。
- `patterns` 含 `InvokePattern` 表示 provider 宣告支援；**工具不呼叫 Invoke，因此不能證明單次允許實際可操作。**
- 根據 `index`／`parent` 看按鈕與命令是否同屬核准區塊。文字報告會用縮排呈現。
- 沒有節點、沒有 Pattern、或沒有找到核准文字，可能是樹視圖、虛擬化、權限、重繪、逾時或 provider 的問題，不能直接判定 App 不支援 UIA。

## 報告資料與回傳

**預設 Name 就可能含對話、命令、帳號、公司路徑與專案名稱；`--include-text` 會增加內容。報告不自動匿名化。** 不要直接把整份報告上傳 GitHub，也不要在未檢查前帶離公司環境。

優先回傳：工具 exit code、header／summary／supervisor，以及核准按鈕、父層及同層命令相關的 node 記錄。請遮蔽敏感文字，保留節點 index／parent、ControlType、Pattern、Enabled／Offscreen、FrameworkId，方便分析結構。

## 原始碼與建置

Windows VS2022／.NET SDK 或可交叉建置 net48 的 .NET SDK：

```powershell
dotnet build .\CodexUiaProbe.csproj -c Release
```

只需要 `Microsoft.NETFramework.ReferenceAssemblies` 作為建置用套件，執行時依賴 Windows 已安裝的 Framework。原始碼及套件鎖定檔隨 ZIP 附上；無需在公司重新建置即可測試 EXE。驗證範圍見 `VERIFICATION.md`。

技術來源：[Microsoft UIA FindAll 與搜尋範圍說明](https://learn.microsoft.com/en-us/dotnet/api/system.windows.automation.automationelement.findall?view=windowsdesktop-10.0)、[UIA 安全模型](https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-securityoverview)。
