# Verification — 2026-10-12

- Cross-built `net48` Release with .NET SDK on macOS: zero warnings/errors.
- Audited the compiled EXE using `System.Reflection.Metadata`: managed entry point and UIA assembly references present; embedded manifest uses `asInvoker` and `uiAccess=false`; 11 native imports are restricted to window enumeration/metadata and process-token queries; no referenced UIA Invoke, setters, focus, selection, scroll, toggle, move/resize actions or network/input APIs in the audited categories.
- The supervisor starts and, on timeout, terminates only its own UIA worker. It does not obtain a target process control handle. `OpenProcess` uses query-limited access (`0x1000`), and tokens use query access (`0x0008`). Reports are bounded, append per node and preserve partial capture.
- Source reviewed for capture scope: only the explicitly selected HWND subtree is traversed. Window selection is manual. TextPattern document text is opt-in and skipped for passwords/unknown password status. No ValuePattern values, screenshots, Codex configuration writes or approval actions.
- Packaged executable/config, source, pinned build dependency lock, documentation and MIT license; archive contents and SHA-256 verified by packaging script.

Not performed: Windows runtime execution, UIA provider compatibility, company application-control policy checks, actual ChatGPT Desktop App 26.803.81509 inspection, target token checks on Windows, worker termination on a stalled Windows provider, foreground/background comparisons, or live approval handling. The API audit is a bounded static check, not a proof of all behavior. This tool deliberately never invokes an approval button.

Reproduce build and compiled API audit:

```sh
dotnet build desktop-probe/CodexUiaProbe.csproj -c Release
dotnet run --project desktop-probe/verify/ProbeAudit.csproj -- desktop-probe/bin/Release/net48/CodexUiaProbe.exe
python3 scripts/package-probe.py
```

Windows acceptance: capture baseline and visible approval in a normal-user session, check header/summary/errors, confirm the pending approval remains pending, inspect relevant parent/child nodes and declared patterns. Missing or partial data must not be interpreted as lack of UIA support.

## 0.1.1 local summary

- Added `--summarize` to analyze an existing local report without another UIA scan. A successful summary has exit code 0 independently of the original capture result.
- Ten portable summary checks passed: content exclusion, missing summary, malformed JSON line status, timeout, button filtering, Invoke declaration, unavailable patterns, adjacent text scope, complete capture and partial error counts.
- Rebuilt net48 EXE with zero warnings/errors; compiled read-only API audit passed again.
- Windows execution and actual 0.1.0 company report analysis remain unverified. Exit code 2 reported by the user establishes an incomplete result, not its underlying cause.

```sh
dotnet run --project desktop-probe/verify/SummaryTests.csproj
```
