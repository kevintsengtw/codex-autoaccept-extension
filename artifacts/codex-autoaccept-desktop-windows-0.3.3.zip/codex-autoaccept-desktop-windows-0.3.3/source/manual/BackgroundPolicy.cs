using System;
internal struct ScreenBox
{
    public double X, Y, Width, Height;
    public ScreenBox(double x, double y, double w, double h) { X=x; Y=y; Width=w; Height=h; }
    public bool Valid => Finite(X) && Finite(Y) && Finite(Width) && Finite(Height) && Width > 0 && Height > 0;
    static bool Finite(double v) { return !double.IsNaN(v) && !double.IsInfinity(v); }
    public bool ContainsCenter(ScreenBox child) => Valid && child.Valid && child.X + child.Width/2 >= X
        && child.X + child.Width/2 < X+Width && child.Y+child.Height/2 >= Y && child.Y+child.Height/2 < Y+Height;
}
internal sealed class WindowSnapshot
{
    public bool Visible, Minimized, Cloaked, NativeKnown, HasForeground, Foreground, RootOffscreen;
    public ScreenBox Frame;
}
internal static class BackgroundPolicy
{
    public static bool CanScan(WindowSnapshot w) => w.NativeKnown && w.Visible && !w.Minimized && !w.Cloaked
        && w.HasForeground && w.Frame.Valid && (!w.RootOffscreen || !w.Foreground);
    public static bool Eligible(WindowSnapshot w, bool enabled, bool invoke, bool offscreen, ScreenBox bounds)
        => CanScan(w) && enabled && invoke && w.Frame.ContainsCenter(bounds)
        && ((!offscreen && !w.RootOffscreen) || !w.Foreground);
    public static bool ProvesAbsence(WindowSnapshot w, int nodes) => CanScan(w) && !w.RootOffscreen && nodes > 1;
    public static bool ProvesHiddenEnd(WindowSnapshot w, bool offscreen) => CanScan(w) && w.Foreground && !w.RootOffscreen && offscreen;
    public static bool NewCycle(bool complete, bool previousPresent, bool newEligibleCandidate)
        => complete && !previousPresent && newEligibleCandidate;
}
