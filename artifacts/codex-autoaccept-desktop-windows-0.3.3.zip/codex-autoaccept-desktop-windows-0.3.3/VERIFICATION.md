# Verification — 2026-10-12

- Cross-built `net48` Release with .NET SDK on macOS: zero warnings/errors.
- Audited the compiled EXE using `System.Reflection.Metadata`: managed entry point and UIA assembly references present; embedded manifest uses `asInvoker` and `uiAccess=false`; 11 native imports are restricted to window enumeration/metadata and process-token queries; no referenced UIA Invoke, setters, focus, selection, scroll, toggle, move/resize actions or network/input APIs in the audited categories.
- The supervisor starts and, on timeout, terminates only its own UIA worker. It does not obtain a target process control handle. `OpenProcess` uses query-limited access (`0x1000`), and tokens use query access (`0x0008`). Reports are bounded, append per node and preserve partial capture.
- Source reviewed for capture scope: only the explicitly selected HWND subtree is traversed. Window selection is manual. TextPattern document text is opt-in and skipped for passwords/unknown password status. No ValuePattern values, screenshots, Codex configuration writes or approval actions.
- Packaged executable/config, source, pinned build dependency lock, documentation and MIT license; archive contents and SHA-256 verified by packaging script.

Not performed: Windows runtime execution, UIA provider compatibility, company application-control policy checks, actual ChatGPT Desktop App 26.803.81509 inspection, target token checks on Windows, worker termination on a stalled Windows provider, foreground/background comparisons, or live approval handling. The API audit is a bounded static check, not a proof of all behavior. This tool deliberately never invokes an approval button.

Reproduce build and compiled API audit:

```sh
dotnet build desktop-probe/CodexUiaProbe.csproj -c Release
dotnet run --project desktop-probe/verify/ProbeAudit.csproj -- desktop-probe/bin/Release/net48/CodexUiaProbe.exe
python3 scripts/package-probe.py
```

Windows acceptance: capture baseline and visible approval in a normal-user session, check header/summary/errors, confirm the pending approval remains pending, inspect relevant parent/child nodes and declared patterns. Missing or partial data must not be interpreted as lack of UIA support.

## 0.1.1 local summary

- Added `--summarize` to analyze an existing local report without another UIA scan. A successful summary has exit code 0 independently of the original capture result.
- Ten portable summary checks passed: content exclusion, missing summary, malformed JSON line status, timeout, button filtering, Invoke declaration, unavailable patterns, adjacent text scope, complete capture and partial error counts.
- Rebuilt net48 EXE with zero warnings/errors; compiled read-only API audit passed again.
- Windows execution and actual 0.1.0 company report analysis remain unverified. Exit code 2 reported by the user establishes an incomplete result, not its underlying cause.

```sh
dotnet run --project desktop-probe/verify/SummaryTests.csproj
```

## 0.1.2 manual one-shot mode

- Kept the read-only probe and the invoking helper in separate assemblies. Read-only API audit passed for CodexUiaProbe; helper audit permits only InvokePattern.Invoke as a UI mutation and rejects other UI/input/network APIs.
- Both net48 projects cross-built with zero warnings/errors.
- Six portable confirmation-gate scenarios passed: no confirmation, cancellation/exact input, one call only, stale target, provider exception with no retry, and validation exception with no retry. Ten existing summary checks also passed.
- Source review: explicit mode, exact-label unique usable button, complete bounded scan, medium integrity checks, local context presentation, fresh scan and identity/context revalidation, final pre-invoke checks, one consumed confirmation, no retry, bounded post-observation. These reduce stale targeting; UIA lacks an atomic approval-request transaction.
- Actual Windows Invoke, company policy allowing the helper EXE, provider timing, cancellation while waiting and observation outcomes remain unverified.
- User-reported 0.1.1 Windows probe result: depth 60 yielded exit 0, zero read errors/boundaries, no node cap, one label Button candidate, one Invoke declaration, one enabled/onscreen candidate. This establishes discovery, not invocation success.

```sh
dotnet build desktop-probe/manual/CodexUiaManualInvoke.csproj -c Release
dotnet build desktop-probe/CodexUiaProbe.csproj -c Release
dotnet run --project desktop-probe/verify/ManualTests.csproj
dotnet run --project desktop-probe/verify/ProbeAudit.csproj -- desktop-probe/manual/bin/Release/net48/CodexUiaManualInvoke.exe manual
```

## 0.2.0 ON/OFF automatic mode

- User confirmed manual INVOKE ONCE removed the pending approval and Codex continued in the company environment. This is user-reported live validation of manual mode only.
- Added an explicit auto mode with terminal O/F/Space/Q controls, default OFF, normal-user integrity checks and no persisted ON setting.
- Thirteen portable state tests passed: revocation/epochs, one commit, no retry across OFF/ON, absence handling, completed original/new identities, stale scan rejection, quit and concurrent commit. Six manual-gate and ten summary checks passed.
- Cross-built both Windows EXEs with zero warnings/errors. API audits passed for the read-only probe and the helper (only InvokePattern.Invoke allowed for UI mutation).
- Original-element removal is required for successful auto observation; enabled/offscreen changes alone are ambiguous and switch OFF. Consumed target keys persist across OFF/ON for the current process; this can conservatively block a new prompt reusing identical UI metadata.
- Automatic Windows execution, company helper execution policy, continuous background polling, actual OFF responsiveness and multiple real approval requests remain unverified. There are no command deny rules or per-chat binding in this UIA prototype.

```sh
dotnet run --project desktop-probe/verify/AutoTests.csproj
```

## User-reported company Windows auto-mode verification — 2026-10-12

Target: ChatGPT Desktop App (Codex) 26.803.81509, standard-user execution, UIA tool 0.2.0.

The user confirmed:

- OFF leaves the approval pending for manual handling.
- Switching ON invokes “允許一次” automatically.
- A second approval is handled normally.
- Switching OFF again stops automatic approvals.

This supersedes the earlier unverified entries for basic automatic invocation, consecutive approvals and ON/OFF behavior in this specific company environment. It is user-reported live validation, not direct agent observation or a general compatibility guarantee. Scan-time OFF races, provider hangs, ambiguous outcomes, terminal shutdown, long-running sessions, minimization, other App versions and multi-chat/window behavior remain unverified. Command rules and per-chat binding remain unimplemented.

Only documentation was updated after this report; the tested 0.2.0 ZIP and executable bytes were preserved.

## 0.2.1 continuous ON correction

The user clarified that 0.2.0 switches OFF after an approval. This supersedes the earlier interpretation of the 0.2.0 live report as successful continuous automatic operation. The implementation indeed switched OFF when a retained/hidden button did not become a stale element within five seconds.

- Removed normal post-invoke automatic OFF and transient scan-error OFF. ON remains ON while waiting/rescanning; failed status logging and provider timeouts can still stop the helper.
- Accepts a stale original element or an offscreen original button in a visible, non-minimized target window as a lifecycle boundary. Disabled visible buttons count as present. Incomplete scans and hidden/minimized windows cannot advance absence detection.
- Resets dedupe only at a verified lifecycle boundary, permitting new approvals that reuse the same UI identity. An OFF/ON toggle alone never retries a consumed attempt.
- Portable lifecycle tests cover twenty consecutive same-identity approvals without another ON action, no duplicate attempt within a cycle, waiting with ON preserved, generation revocation, absence detection and concurrent attempts. Manual and summary tests and API audits passed.
- Windows company validation of 0.2.1 remains pending. UIA lifecycle observations are not protocol request IDs; a boundary that cannot be observed will keep the tool waiting.

## User-reported 0.2.1 continuous auto-mode verification — 2026-10-12

Company environment: ChatGPT Desktop App (Codex) 26.803.81509; standard-user execution; UIA tool 0.2.1.

The user confirmed that pressing O only once handled three consecutive “允許一次” approvals automatically while remaining ON. Pressing F then stopped automatic approvals. This validates the continuous-ON correction in this specific environment and supersedes the preceding pending status for 0.2.1.

This is user-reported live verification, not direct agent observation. Other App versions, long-running sessions, race conditions, hidden/minimized windows and provider failures remain outside the reported validation. Terminal CLI scenarios remain pending independently.

Only README and verification documentation were updated; no executable changes or repackaging were performed.

## 0.3.0 Windows tray frontend

- Added net48 Windows GUI frontend with NotifyIcon, target picker, mouse ON/OFF, close-to-tray, explicit quit, single instance and optional HKCU Run login startup. User explicitly selected OFF on every process start; only App path is persisted.
- Headless backend uses inherited stdin/stdout pipes and CreateNoWindow. ON/OFF acknowledgement is separate from requested intent. EOF or QUIT stops the backend; callbacks are fenced to the active Process instance.
- App reattachment requires a unique matching saved executable path; PID/start-time checks protect against HWND reuse. If path metadata is inaccessible, explicitly selected windows still work for that session without automatic path binding.
- Frontend fault/timeout displays a paused state; it never silently restarts and repeats an ambiguous approval. Explicit reconnect resets OFF. Host exit closes pipe/requests worker termination; already submitted provider actions cannot be rolled back.
- Twelve portable frontend lifecycle tests passed, plus existing 20-request auto lifecycle simulation, six manual-gate and ten summary checks.
- All three net48 EXEs cross-built without warnings/errors. Frontend PE audit verifies WindowsGui subsystem and asInvoker, with six window/icon native APIs and no UIA mutations. Backend API audit still permits only InvokePattern.Invoke for UI mutation; probe remains read-only.
- Not executed on Windows: GUI layout/DPI, notification-area behavior, real pipe lifecycle, reconnect, corporate application control, registry registration and login startup. This is a desktop UX implementation built around the user-validated 0.2.1 core; Windows acceptance remains required.

```sh
dotnet build desktop-probe/tray/CodexAutoAcceptDesktop.csproj -c Release
dotnet run --project desktop-probe/verify/DesktopTests.csproj
dotnet run --project desktop-probe/verify/ProbeAudit.csproj -- desktop-probe/tray/bin/Release/net48/CodexAutoAcceptDesktop.exe tray
```

## 0.3.1 headless startup correction

User reported that 0.3.0 immediately shows backend stopped, including after reconnect. Inspection found an initialization defect: Console.OutputEncoding was set before the try block, although CreateNoWindow removes the console. The Framework reference source calls SetConsoleOutputCP and throws on failure without checking output redirection. This establishes a relevant defect, not a confirmed trace from the company machine.

- Headless mode now installs UTF-8 standard stream readers/writers without setting console code pages. Initialization is inside error handling, and backend version is emitted before argument/window checks.
- Added actual redirected child-process transport tests: READY, Chinese UTF-8 output, ON/OFF commands with optional input BOM, QUIT and host EOF. They run on the current host (.NET 8/macOS); exact net48/Windows execution remains pending.
- Added seven diagnostic tests for version mismatch, safe error classification, exit codes and attempt tracking. Frontend lifecycle now includes connecting-state checks (13 checks).
- UI sequence is numbered and ordered choose → ON → reconnect. ON is disabled until READY from a compatible backend. Reconnect reuses a valid explicitly selected target even when no path can be persisted.
- Exit handling drains redirected streams before showing safe diagnostic metadata; diagnostic capture does not discard early errors merely because the process has already exited. Late control messages still cannot revive an exited worker.
- All three net48 projects build and API audits pass. Continuous auto/manual/summary regression checks pass. Company 0.3.1 end-to-end execution remains unverified.

Reference: https://github.com/microsoft/referencesource/blob/main/mscorlib/system/console.cs (OutputEncoding setter).

## 0.3.2 startup permission metadata correction

User reported exit 4 / ManualRefusalException before an approval attempt in 0.3.1. The only such pre-READY refusal is the exact-medium token check; actual values were not previously surfaced in the GUI. We have not observed the company process tokens and cannot conclude elevated privileges are required.

- Integrity query now distinguishes untrusted, low, medium range, medium-plus range, high, system and unavailable. Current-process query uses its pseudo handle. Unavailable results include query stage and Win32 error, without paths/user names.
- Known high/system tool or target remains rejected. Other levels and unknown metadata can initialize, with all real UIA access and invocation still governed by Windows. This does not grant UIAccess, elevate, or change corporate policy. Unknown token metadata is not reported as success.
- Added permission-policy and diagnostic privacy tests for lower/standard ranges, unknown queries, known elevated rejection, parsing stage/error codes and preserving no-attempt vs ambiguous-attempt status.
- GUI exposes levels on successful handshake and startup failure, plus UIA minimized/root-offscreen/button-offscreen states. This is diagnostic instrumentation, not a background-occlusion fix.
- Windows company 0.3.2 startup and background behavior remain unverified. Existing transport, frontend/core/manual/summary checks and compiled API audits run as regression checks.

## User-reported 0.3.2 success — 2026-10-12

The user confirmed normal-user CodexAutoAcceptDesktop connects without startup errors, detects a subsequent “允許一次” approval, invokes it and continues monitoring with incrementing count. This supersedes the pending basic tray/startup status for this company environment. Background occlusion remained unverified and was specifically requested next.

## 0.3.3 background visibility policy

- Native read-only snapshot adds WS_VISIBLE, IsIconic, DWM frame bounds/cloak and GetForegroundWindow. No foreground/focus/restore/move APIs are added. Modal-blocked roots are not acted on.
- A background root/button IsOffscreen hint no longer unconditionally blocks eligible UIA buttons. Background candidates require exact label, enabled/Invoke, valid finite geometry with center inside target frame, uniqueness and existing fresh identity/context checks.
- Offscreen alone in background cannot complete the previous request. Root-offscreen/empty-tree uncertainty cannot advance absence rearming. A complete scan with old runtime ID absent and a distinct eligible new candidate can advance the cycle.
- Portable policy scenarios passed for covered windows, offscreen hints, geometry rejection, minimized/cloaked/hidden/no-active-desktop cases, foreground compatibility, negative monitor coordinates, dedupe and next-background-request progression.
- Existing startup/permission, transport, frontend, manual/core/summary tests run as regression checks. Three EXEs cross-build and compiled API audits verify the backend's only UI mutation is InvokePattern.Invoke, with 14 allowlisted read-only native imports.
- Not performed: actual company Windows occlusion, renderer accessibility updates while covered, multi-DPI DWM/UIA alignment, modal/provider behavior or focus changes initiated by the App itself. If App publishes no active UIA button in the background, this client cannot manufacture it; it reports BACKGROUND_PROVIDER_LIMITED and waits without foregrounding.
